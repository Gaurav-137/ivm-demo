  export const ArrowRight: LucideIcon;
