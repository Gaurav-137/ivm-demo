#!/bin/bash
echo "Updating Expo packages to their expected versions..."
echo ""

npm install

echo ""
echo "Packages updated successfully!"
echo ""